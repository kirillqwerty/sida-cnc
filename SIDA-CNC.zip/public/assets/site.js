// Optional enhancements only. All page content is authored in the HTML files.
document.documentElement.classList.add('js');
const heroVideo = document.querySelector('.hero-video');
const videoToggle = document.querySelector('.video-toggle');
if (heroVideo && videoToggle) {
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let manuallyPaused = false;
  function updateVideoButton() {
    const label = heroVideo.paused ? 'Воспроизвести видео' : 'Пауза видео';
    videoToggle.textContent = label;
    videoToggle.setAttribute('aria-label', label + ' на фоне');
  }
  async function playVideo() {
    try { await heroVideo.play(); } catch { /* Poster remains visible if autoplay is blocked. */ }
    updateVideoButton();
  }
  videoToggle.hidden = false;
  heroVideo.addEventListener('play', updateVideoButton);
  heroVideo.addEventListener('pause', updateVideoButton);
  videoToggle.addEventListener('click', () => {
    manuallyPaused = !heroVideo.paused;
    heroVideo.paused ? playVideo() : heroVideo.pause();
  });
  reducedMotion.addEventListener('change', () => {
    if (reducedMotion.matches) heroVideo.pause();
  });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) heroVideo.pause();
    else if (!manuallyPaused && !reducedMotion.matches && !navigator.connection?.saveData) playVideo();
  });
  if (!reducedMotion.matches && !navigator.connection?.saveData) playVideo();
}

const menuButton = document.querySelector('.menu-toggle');
const menu = document.querySelector('.main-nav');
menuButton?.addEventListener('click', () => {
  const open = menuButton.getAttribute('aria-expanded') !== 'true';
  menuButton.setAttribute('aria-expanded', String(open));
  menu?.classList.toggle('is-open', open);
});

const normalize = (value) => value.toLocaleLowerCase('ru').replace(/[\s-]+/g, '');
const search = document.querySelector('#model-search');
const cards = [...document.querySelectorAll('[data-model]')];
const groups = [...document.querySelectorAll('[data-search-group]')];
const empty = document.querySelector('[data-empty-search]');
const count = document.querySelector('#search-count');

function applySearch(value) {
  const query = normalize(value);
  let visible = 0;
  cards.forEach((card) => {
    const match = !query || normalize(`${card.dataset.model} ${card.dataset.category}`).includes(query);
    card.hidden = !match;
    if (match) visible += 1;
  });
  groups.forEach((group) => { group.hidden = ![...group.querySelectorAll('[data-model]')].some((card) => !card.hidden); });
  if (empty) empty.hidden = visible > 0;
  if (count) count.textContent = query ? `Найдено моделей: ${visible}` : `${cards.length} моделей в каталоге`;
  const url = new URL(location.href);
  value ? url.searchParams.set('q', value) : url.searchParams.delete('q');
  if (location.protocol !== 'file:') history.replaceState(null, '', url);
}

if (search) {
  document.querySelector('.catalog-search').hidden = false;
  const initial = new URL(location.href).searchParams.get('q') || '';
  search.value = initial;
  applySearch(initial);
  search.addEventListener('input', () => applySearch(search.value));
  document.querySelectorAll('[data-clear-search]').forEach((button) => button.addEventListener('click', () => { search.value = ''; applySearch(''); search.focus(); }));
}

function setError(form, name, message) {
  const field = form.elements[name];
  const error = form.querySelector(`[data-error-for="${name}"]`);
  if (field?.setAttribute) field.setAttribute('aria-invalid', message ? 'true' : 'false');
  if (error) error.textContent = message;
}

document.querySelectorAll('[data-request-form]').forEach((form) => {
  form.noValidate = true;
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(form));
    ['name', 'phone', 'email', 'message', 'consent'].forEach((name) => setError(form, name, ''));
    let valid = true;
    if ((data.name || '').trim().length < 2) { setError(form, 'name', 'Укажите имя'); valid = false; }
    if (!(data.phone || '').trim() && !(data.email || '').trim()) { setError(form, 'phone', 'Укажите телефон или email'); valid = false; }
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) { setError(form, 'email', 'Проверьте email'); valid = false; }
    if (form.elements.message.required && !(data.message || '').trim()) { setError(form, 'message', 'Опишите задачу'); valid = false; }
    if (!data.consent) { setError(form, 'consent', 'Необходимо согласие'); valid = false; }
    if (!valid) return;
    const button = form.querySelector('button[type=submit]');
    const status = form.querySelector('.form-status');
    button.disabled = true; status.className = 'form-status'; status.textContent = 'Отправляем…';
    try {
      if (location.protocol === 'file:') throw new Error('Для отправки заявки откройте сайт через локальный сервер или хостинг.');
      const response = await fetch(form.action, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message || 'Не удалось отправить заявку');
      status.classList.add('is-success'); status.textContent = result.message;
      form.reset();
    } catch (error) {
      status.classList.add('is-error'); status.textContent = error.message || 'Ошибка соединения. Попробуйте ещё раз.';
    } finally { button.disabled = false; }
  });
});
